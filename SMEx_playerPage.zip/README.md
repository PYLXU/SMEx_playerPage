# SMEx_playerPage

[SimMusic扩展]适用于 SimMusic 的 播放页面 美化扩展

## 扩展截图

![e2defed7043ee3e9a946a89bc7deb98f](https://github.com/user-attachments/assets/be6f5e8a-22cd-46c5-8a27-14096b27cbee)
![809f5699a3028e41047e39ac0e9ea6c4](https://github.com/user-attachments/assets/38e92caf-b2f3-4993-8c01-56166538e067)
![2a7b7ac59e5fdcafe18977008066700b](https://github.com/user-attachments/assets/03a11c99-0836-4ece-8e54-44dc12a45e62)
![731cf6f0125a0bc083e8607f40a0583c](https://github.com/user-attachments/assets/6eb61650-a599-4f7f-a806-a273c059817f)


## 安装教程

### 方式：直接安装

1. 下载此扩展到任意位置
2. 安装SimMusic后，打开「扩展」页面，将此扩展拖入扩展页面后点击「确认」按钮安装

## 扩展说明

1. 若扩展存在Bug请及时[提交](https://github.com/PYLXU/SMEx_playerPage/issues)，非常感谢
2. 必须同时启用官方设置项：播放页深色模式

## 特别鸣谢

- SimMusic为本扩展提供开发平台
