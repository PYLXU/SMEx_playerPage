var scripts = `

        `;
includeScriptElement(scripts);